To take full advantage of these downloads, please purchase The Sun Certified Java Developer Exam with J2SE 1.4 and use the detailed directions in Chapter 8.

In short,
1. create a classes directory.
2. compile your application there(per the instructions on page 320)
3. inside of classes, create a dvd_db directory(see fig 8-6)
4. run java sampleproject.db.DOSClient from the classes directory, and choose option 8.(see fig 8-6)
5. Run the application from the classes directory(see figure 8-7, or use java sampleproject.gui.ApplicationRunner) 